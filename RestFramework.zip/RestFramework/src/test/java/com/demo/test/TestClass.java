package com.demo.test;

import java.util.HashMap;

import org.databene.benerator.anno.Source;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.demo.base.Base;
import com.demo.pages.HomePage;
import com.demo.pojo.ConfigPojo;
import com.demo.uiUtil.DriverManager;
import com.demo.uiUtil.WebDriverFactory;

public class TestClass extends Base{

	WebDriver driver = null;
	DriverManager driverManager = null;
	
	@BeforeTest
	public void beforeTest() {
		Base base = new Base();
		driverManager = WebDriverFactory.getManager("chrome");
		driver = driverManager.createDriver();
		base.setUp();
	}
	
	@Test(dataProvider = "feeder")
	@Source("input\\testInput.csv")
	public void testFunc1(String testCaseID, String testCaseName, String productName, String expectedCartCount) {
		
		driver.get(ConfigPojo.webURL);
		HomePage homePage = new HomePage(driver);
		homePage.searchProduct(productName);
		homePage.clickFirstElement();
		homePage.clickAddToCart();
		Assert.assertEquals(homePage.getCartCount(), expectedCartCount);
	}
	
	@AfterTest
	public void afterTest() {
		driverManager.quitDriver(driver);
	}
}
