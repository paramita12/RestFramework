package com.demo.test;

import org.databene.benerator.anno.Source;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.demo.base.Base;
import com.demo.constant.Constant;
import com.demo.util.RestUtil;
import java.util.Map;

import io.restassured.response.Response;
import io.restassured.path.json.JsonPath;

public class TestClassAPI extends Base{
	
	@Test(dataProvider = "feeder")
	@Source("input\\testInputAPI.csv")
	public void testFunc1(String testCaseID, String testCaseName, String apiMethod, String expectedStatusCode) {

		RestUtil restUtil = new RestUtil();
		Response response = restUtil.apiCall(Constant.currentPrice, apiMethod);

		Assert.assertEquals(response.getStatusCode(), Integer.parseInt(expectedStatusCode), "Status code does not match");

		JsonPath jsonPath = response.jsonPath();

		Map<String, Object> bpi = jsonPath.getMap("bpi");
		Assert.assertNotNull(bpi, "BPI section is missing in the response");
		Assert.assertTrue(bpi.containsKey("USD"), "BPI does not contain USD");
		Assert.assertTrue(bpi.containsKey("GBP"), "BPI does not contain GBP");
		Assert.assertTrue(bpi.containsKey("EUR"), "BPI does not contain EUR");

		Map<String, Object> gbpDetails = jsonPath.getMap("bpi.GBP");
		Assert.assertNotNull(gbpDetails, "GBP details are missing");
		Assert.assertEquals(gbpDetails.get("description"), "British Pound Sterling", "GBP description does not match");

	}
}
