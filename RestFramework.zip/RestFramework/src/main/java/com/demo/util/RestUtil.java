package com.demo.util;

import com.demo.pojo.ConfigPojo;

import io.restassured.RestAssured;
import io.restassured.http.Method;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class RestUtil {
	
	public Response apiCall(String endPoint, String apiType) {
		
		Response response = null;
		RestAssured.baseURI = ConfigPojo.baseURI;
		RequestSpecification request = RestAssured.given();
		request.header("Content-Type","application/json");
		
		switch(apiType.toUpperCase()) {
			case "GET":
				response = request.request(Method.GET, endPoint);
				break;
			case "POST":
				response = request.request(Method.POST, endPoint);
				break;
			case "PUT":
				response = request.request(Method.PUT, endPoint);
				break;
			case "DELETE":
				response = request.request(Method.DELETE, endPoint);
				break;
		}
		response.then().log().all();
		return response;		
	}
}
