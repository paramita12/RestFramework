package com.demo.pojo;


public class ConfigPojo {

	public static String configFile = null;
	public static String baseURI = null;
	public static String webURL = null;
}
