package com.demo.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class HomePage {

    WebDriver driver;
	
	@FindBy(id = "gh-ac")
	WebElement SearchTextBox;
	
	@FindBy(id = "gh-btn")
	WebElement SearchButton;

    @FindBy(xpath = "(//*[@id='srp-river-results']//li[@class='s-item s-item__pl-on-bottom']//div[@class='s-item__image'])[1]")
    WebElement firstElement;

    @FindBy(xpath = "//span[text()='Add to cart']")
    WebElement addToCartButton;

    @FindBy(id = "gh-cart-n")
    WebElement cartCount;

    public HomePage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

    public void searchProduct(String productName) {
        SearchTextBox.sendKeys(productName);
        SearchButton.click();
    }

    public void clickFirstElement() {
        firstElement.click();
    }

    public void clickAddToCart() {
        driver.getWindowHandles().forEach(handle -> driver.switchTo().window(handle));
        addToCartButton.click();
    }
    
    public String getCartCount() {
        return cartCount.getText();
    }

}
